<?php
if(isset($_GET["page"])){
    if($_GET["page"] != "home")return;
}
?>
<h1>Home</h1>
<p>Site met artiesten en uit welk land ze komen</p>