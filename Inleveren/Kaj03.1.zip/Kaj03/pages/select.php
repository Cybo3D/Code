<?php
if (isset($_GET["page"])) {
    if ($_GET["page"] != "select")
        return;
} else {
    return;
}

$artist = [];

$res = mysqli_query($conn, "SELECT * FROM artist");

while ($row = mysqli_fetch_assoc($res)) {
    $artist[] = [
        0 => $row["id"],
        1 => $row["name"],
        2 => $row["country"],
    ];
}
$info = "";
for ($x = 0; $x < count($artist); $x++) {
    $info = $info . "<tr>";

    for ($y = 1; $y < count($artist[$x]); $y++) {
        $info = $info . "<td>";

        $info = $info . $artist[$x][$y];

        $info = $info . "</td>";
    }

    $info = $info . "</tr>";
}
?>
<div class='table' id='cameras'>
    <h1>artists</h1>
    <table>
        <tr>
            <th>address</th>
            <th>city</th>
        </tr>
        <?= $info ?>
    </table>
</div>